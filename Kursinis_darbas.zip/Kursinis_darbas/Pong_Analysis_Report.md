
# 🕹️ In-Depth Technical Analysis of `Pong.py`

## Overview
This Python program recreates the classic Pong game using the `pygame` library. It features two paddles (controlled by W/S and ↑/↓), a bouncing ball, scorekeeping, and a win condition. The game resets when a player reaches the winning score(Can be easily changed).

---

## 1. Game Setup and Initialization

### Pygame Initialization
```python
pygame.init()
```
Initializes all imported `pygame` modules.

### Screen and Clock Setup
```python
WIDTH, HEIGHT = 700,500
WIN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Pong")
FPS = 60
```
- 700x500 window titled “Pong”.
- FPS cap ensures consistent performance across machines.

---

## 🧱 Object-Oriented Programming Principles in Use

### ✅ Encapsulation

**Definition**: Bundling data (attributes) and methods that operate on that data within one unit (class), and restricting direct access to some of an object's components.

**Where It's Used**:
- Classes `Paddle`, `Ball`, and `GameObject` encapsulate position and movement logic.
- Internal attributes (`x`, `y`, `radius`, `x_vel`, `y_vel`) are not accessed directly from outside.
- Public methods like `move()` and `reset()` provide controlled interaction with object state.

```python
def move(self):
    self.x += self.x_vel
    self.y += self.y_vel
```

---

### ✅ Abstraction

**Definition**: Hiding internal complexity and exposing only essential features.

**Where It's Used**:
- `GameObject` defines an abstract interface via `draw()` and `reset()` methods.
- Subclasses (`Paddle`, `Ball`) implement these methods, abstracting rendering logic from the main loop.

```python
class GameObject:
    def draw(self, win):
        raise NotImplementedError
```

---

### ✅ Inheritance

**Definition**: The mechanism of basing a class on another class.

**Where It's Used**:
- `Paddle` and `Ball` inherit from `GameObject`, gaining access to shared attributes and behavior.

```python
class Paddle(GameObject):
    ...
class Ball(GameObject):
    ...
```

---

### ✅ Polymorphism

**Definition**: The ability to use objects of different classes through the same interface.

**Where It's Used**:
- Both `Paddle` and `Ball` implement `draw(win)`, allowing them to be drawn via a loop using `draw()`.

```python
for obj in game_objects:
    obj.draw(win)
```

---

## 🧩 Composition & Aggregation

### ✅ Composition (Partial)

**Definition**: One object contains another and manages its lifecycle.

**Where It's Present**:
- `main()` groups objects and logic, but no class owns the full game structure.
- A dedicated `Game` class would enhance composition.

```python
game_objects = [left_paddle, right_paddle]
```

### 🟡 Aggregation (Loose)

**Definition**: "Has-a" relationships where the lifetimes of objects are independent.

**Where It's Present**:
- `draw()` receives `game_objects` and draws them without managing their state or creation.

---

## 🧠 Design Patterns

### ✅ Composite Pattern
- Used in the `draw()` method where a list of `GameObject` subclasses (`Paddle`) are iterated and drawn.

```python
for obj in game_objects:
    obj.draw(win)
```

##  Class: Ball

### Design
```python
class Ball(GameObject):
```
Game ball representation.

#### Attributes
- `x`, `y`, `origin_x`, `origin_y`: Position tracking.
- `radius`: Size.
- `x_vel`, `y_vel`: Velocity in pixels/frame.

#### Methods
- `draw(win)`
- `move()`
- `reset()`

**Highlight**: Ball angle changes dynamically based on paddle hit location.

---

##  Drawing Function

### Core Rendering
```python
def draw(win, paddles, ball, left_score, right_score):
```
- Clears and redraws game objects.
- Renders dashed center line.

---

##  Collision Handling

### Ball-Paddle Physics
```python
def handle_collision(ball, left_paddle, right_paddle):
```
- Inverts `y_vel` on wall contact.
- Reflects `x_vel` and calculates dynamic `y_vel` on paddle hit:
```python
difference_in_y = middle_y - ball.y
reduction_factor = (paddle.height / 2) / ball.MAX_VEL
y_vel = difference_in_y / reduction_factor
ball.y_vel = -1 * y_vel
```

---

##  Paddle Movement Logic

### Keyboard Input Mapping
```python
def handle_paddle_movement(keys, left_paddle, right_paddle):
```
- `W/S` for left paddle.
- `↑/↓` for right paddle.

**Improvement**: Use abstraction for joystick/AI input support.

---

##  Main Game Loop

### Structure
```python
def main():
```
- Initializes objects.
- Handles events and updates.
- Tracks and resets score.
- Detects win and pauses before resetting.

---

##  Game Ending Condition

### Victory Check
```python
if left_score >= WINNING_SCORE or right_score >= WINNING_SCORE:
```
- Displays winner message.
- Pauses 5 seconds before reset.

---

## Potential Enhancements

| Feature | Description |
|--------|-------------|
| **AI Opponent** | Add single-player mode |
| **Sound Effects** | Use `pygame.mixer` |
| **Menus** | Add main/pause/end screens |
| **Power-ups** | Increase replayability |
| **Physics Enhancements** | Add friction/spin |
| **Dynamic Resizing** | Resolution independence |

---

## Results

1. Had to use chat gpt to refactor the program to include all 4 foundations of OOP
2. The program, while simple, Is in my opinion, a decent recreation of the game Pong
3. Could be further expanded upon, including features like sound effects, an AI opponent, pause menu etc.

---

## Conclusion

| Feature              | Status | Notes |
|----------------------|--------|-------|
| **Encapsulation**     | ✅ Good | Proper method-based control of internal state |
| **Abstraction**       | ✅ Used | Abstract base class separates concerns |
| **Inheritance**       | ✅ Used | Code reuse via base class |
| **Polymorphism**      | ✅ Used | Interface consistency for draw/reset |
| **Composition**       | 🟡 Partial | Present in logic, not structured in classes |
| **Aggregation**       | 🟡 Loose | Used via function-level grouping |
| **Composite Pattern** | ✅ Present | For rendering grouped objects |
| **Other Patterns**    | ❌ Not Present | No Factory/Builder/Singleton usage |

---